// import React from "react";
// import Cardone from "../Media/Home/Asset 1.png";
// import Cardtwo from "../Media/Home/Asset 2.png";
// import Cardthree from "../Media/Home/Asset 3.png";
// import Cardfour from "../Media/Home/Asset 8.png";
// import Cardfive from "../Media/Home/Asset 4.png";
// import Cardsix from "../Media/Home/Asset 5.png";
// import Cardseven from "../Media/Home/Asset 6.png";
// import Cardeight from "../Media/Home/Asset 7.png";
// import bgvideo from "../Media/Common/bg.mp4";
// import bghomehead from "../Media/Home/heading.png";

// import { Link } from "react-router-dom";

// function Selection() {
//   return (
//     <div className="selection-carousel">
//       <div className="selection-carousel-heading">
//         <div className="selection-carousel-headingcontentmain">
//           <img src={bghomehead} width="320px" height="70px" />
//         </div>
//         <div className="selection-carousel-button-mains">
//           <Link to="/screenone">
//             <div>
//               <img src={Cardone} />
//             </div>
//           </Link>

//           <Link to="/screentwo">
//             <div>
//               <img src={Cardtwo} />
//             </div>
//           </Link>

//           <Link to="/screenthree">
//             <div>
//               <img src={Cardthree} />
//             </div>
//           </Link>

//           <Link to="/screenfour">
//             <div>
//               <img src={Cardfour} />
//             </div>
//           </Link>
//         </div>

//         <div className="selection-carousel-button-mainsone">
//           <Link to="/screenfive">
//             <div>
//               <img src={Cardfive} />
//             </div>
//           </Link>

//           <Link to="/screensix">
//             <div>
//               <img src={Cardsix} />
//             </div>
//           </Link>

//           <Link to="/screenseven">
//             <div>
//               <img src={Cardseven} />
//             </div>
//           </Link>

//           <Link to="/screeneight">
//             <div>
//               <img src={Cardeight} />
//             </div>
//           </Link>
//         </div>
//       </div>
//       <video
//         id="Video1"
//         controls={false}
//         width="100%"
//         src={bgvideo}
//         autoPlay={true}
//         loop={true}
//         muted={true}
//         playsInline={true}
//       />
//     </div>
//   );
// }

// export default Selection;







// import React, { useState } from "react";
// import { Link } from "react-router-dom"; // Import Link component

// import Asset6 from "../Media/Home/Asset 6@4x.png";
// import Asset7 from "../Media/Home/Asset 7@4x.png";
// import Asset8 from "../Media/Home/Asset 8@4x.png";
// import Asset9 from "../Media/Home/Asset 9@4x.png"; // New background image

// function Selection() {
//   const [activeImage, setActiveImage] = useState(null);

//   const handleTouchStart = (image) => {
//     setActiveImage(image);
//   };

//   const handleTouchEnd = () => {
//     setActiveImage(null);
//   };

//   return (
//     <div className="selection-carousel" style={{backgroundImage: `url(${Asset9})`}}>
//       <div className="selection-carousel-button-mains">
//         <a href="https://play.kahoot.it/v2/?quizId=e7e24bae-5d26-4aa2-8863-fea9d22c287c&hostId=7772bc94-3729-455e-b869-07ca9b033d51">
//           <div
//             className={`image-container ${activeImage === "Asset8" ? "active" : ""}`}
//             onTouchStart={() => handleTouchStart("Asset8")}
//             onTouchEnd={handleTouchEnd}
//           >
//             <img src={Asset8} alt="Asset8" />
//           </div>
//         </a>

//         <a href="https://play.kahoot.it/v2/?quizId=cae0502d-fc08-4268-b76c-54fb09fbdcf6&hostId=7772bc94-3729-455e-b869-07ca9b033d51">
//           <div
//             className={`image-container ${activeImage === "Asset7" ? "active" : ""}`}
//             onTouchStart={() => handleTouchStart("Asset7")}
//             onTouchEnd={handleTouchEnd}
//           >
//             <img src={Asset7} alt="Asset7" />
//           </div>
//         </a>

//         <a href="https://play.kahoot.it/v2/?quizId=cae0502d-fc08-4268-b76c-54fb09fbdcf6&hostId=7772bc94-3729-455e-b869-07ca9b033d51">
//           <div
//             className={`image-container ${activeImage === "Asset6" ? "active" : ""}`}
//             onTouchStart={() => handleTouchStart("Asset6")}
//             onTouchEnd={handleTouchEnd}
//           >
//             <img src={Asset6} alt="Asset6" />
//           </div>
//         </a>
//       </div>
//     </div>
//   );
// }

// export default Selection;

import React, { useState } from "react";
import { Link } from "react-router-dom"; // Import Link component

import Asset6 from "../Media/Home/Asset 6@4x.png";
import Asset7 from "../Media/Home/Asset 7@4x.png";
import Asset8 from "../Media/Home/Asset 8@4x.png";
import Asset9 from "../Media/Home/Asset 9@4x.png"; // New background image

// Import the new home button image
import homeButtonImage from "../Media/Home/Asset 23@4x.png";

function Selection() {
  const [activeImage, setActiveImage] = useState(null);
  const [showKahoot, setShowKahoot] = useState(false);
  const [currentQuizId, setCurrentQuizId] = useState(null);

  const handleTouchStart = (image) => {
    setActiveImage(image);
    setShowKahoot(false); // Hide Kahoot when switching between tabs
  };

  const handleTouchEnd = () => {
    setActiveImage(null);
  };

  const openKahootFullscreen = (quizId) => {
    setCurrentQuizId(quizId);
    setShowKahoot(true); // Show Kahoot for the selected quiz
  };

  const closeKahootFullscreen = () => {
    setShowKahoot(false); // Close Kahoot
  };

  return (
    <div className="selection-carousel" style={{ backgroundImage: `url(${Asset9})` }}>
      <div className="selection-carousel-button-mains">
        <div className={`image-container ${activeImage === "Asset8" ? "active" : ""}`}
          onTouchStart={() => handleTouchStart("Asset8")}
          onTouchEnd={handleTouchEnd}
          onClick={() => openKahootFullscreen("c0e0d24c-f40e-4dcf-b311-ee610646b353")}>
          <img src={Asset8} alt="Asset8" />
        </div>

        <div className={`image-container ${activeImage === "Asset7" ? "active" : ""}`}
          onTouchStart={() => handleTouchStart("Asset7")}
          onTouchEnd={handleTouchEnd}
          onClick={() => openKahootFullscreen("3a01ea9f-49d1-417a-beab-f92a9876b473")}>
          <img src={Asset7} alt="Asset7" />
        </div>

        <div className={`image-container ${activeImage === "Asset6" ? "active" : ""}`}
          onTouchStart={() => handleTouchStart("Asset6")}
          onTouchEnd={handleTouchEnd}
          onClick={() => openKahootFullscreen("7f60f80f-99cf-41f9-8f48-29b7e7e98e34")}>
          <img src={Asset6} alt="Asset6" />
        </div>
      </div>

      {showKahoot && (
        <div className="kahoot-container">
          <iframe
            src={`https://play.kahoot.it/v2/?quizId=${currentQuizId}&hostId=7772bc94-3729-455e-b869-07ca9b033d51`}
            style={{ width: "100%", height: "100vh", position: "absolute", top: 0, left: 0, zIndex: 9999 }}
          ></iframe>
          {/* Home button */}
          <div className="home-tab-container">
            <Link to="/" className="floating-home-button" onClick={closeKahootFullscreen}>
              <img src={homeButtonImage} alt="Home" />
            </Link>
          </div>
        </div>
      )}

    </div>
  );
}

export default Selection;





