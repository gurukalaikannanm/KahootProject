import React from "react";

function StartIcon({ onStartClick }) {
  return (
    <div className="start-icon" onClick={onStartClick}>
      {/* Add your start icon */}
      <i className="fas fa-play"></i>
    </div>
  );
}

export default StartIcon;
