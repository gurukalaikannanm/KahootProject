import React, { Fragment } from "react";
import { Route, Routes } from "react-router-dom";
import SelectionMain from "./Components/SelectionMain";
//Screens
import Screenone from "./Screens/One/Screenone";
import Screentwo from "./Screens/Two/Screentwo";
import Screenthree from "./Screens/Three/Screenthree";
import Screenfour from "./Screens/Four/Screenfour";
import Screenfive from "./Screens/Five/Screenfive";
import Screensix from "./Screens/Six/Screensix";
import Screenseven from "./Screens/Seven/Screenseven";
import Screeneight from "./Screens/Eight/Screeneight";

function App() {
  return (
    <Fragment>
      <Routes>
        <Route path="/" element={<SelectionMain />} />
        <Route path="/screenone" element={<Screenone />} />
        <Route path="/screentwo" element={<Screentwo />} />
        <Route path="/screenthree" element={<Screenthree />} />
        {/* <Route path="/screenfour" element={<Screenfour />} />
        <Route path="/screenfive" element={<Screenfive />} />
        <Route path="/screensix" element={<Screensix />} />
        <Route path="/screenseven" element={<Screenseven />} />
        <Route path="/screeneight" element={<Screeneight />} /> */}
      </Routes>
    </Fragment>
  );
}

export default App;
