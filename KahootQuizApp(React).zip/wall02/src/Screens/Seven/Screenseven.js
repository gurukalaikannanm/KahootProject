import React from "react";
import Cardone from "../../Media/Button_06/Asset 17@2x.png";
import Homebtn from "../../Media/Common/home.png";
import bgvideo from "../../Media/Common/bg.mp4";
import { Link } from "react-router-dom";

const Screenseven = () => {
  return (
    <div className="selection-carousel">
      <div className="selection-carousel-heading">
        <div className="homebtnmain">
          <div className="selection-carousel-button-mainschild">
            <img src={Cardone} />
          </div>

          <div className="homebtnchild">
            <Link to="/">
              <img src={Homebtn} />
            </Link>
          </div>
        </div>
      </div>

      <video
        id="Video1"
        controls={false}
        width="100%"
        src={bgvideo}
        autoPlay={true}
        loop={true}
        muted={true}
        playsInline={true}
      />
    </div>
  );
};

export default Screenseven;
